# RELEASE NOTE v2.0

Version initiale du Knowledge Pack.

Les futures mises à jour seront préparées par ChatGPT sous forme d'un nouveau pack.
