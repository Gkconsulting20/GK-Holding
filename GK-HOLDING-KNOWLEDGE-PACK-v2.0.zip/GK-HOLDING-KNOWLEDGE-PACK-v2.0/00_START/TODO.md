# TODO

Priorités :
1. Développer YouTube
2. Créer GK Holding
3. Développer ORIONEXA
