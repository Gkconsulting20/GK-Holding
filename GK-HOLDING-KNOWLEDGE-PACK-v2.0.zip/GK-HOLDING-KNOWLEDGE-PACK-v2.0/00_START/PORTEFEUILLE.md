# PORTEFEUILLE

## Actifs
- YouTube
- GK Holding
- ORIONEXA
- OriRisk AI
- ProchezNous
- AgriRéseau
- AFPE

## Incubation
- ComptaOrion
- Orilearn
- ELAYI

## Pause
- Tous les projets agricoles

## Abandonnés
- À compléter
