# GK HOLDING KNOWLEDGE PACK

Base documentaire officielle.
